from django.shortcuts import render, redirect
from .forms import *
from django.shortcuts import render, get_object_or_404
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.db import transaction
from .forms import *

from django.http import HttpResponse
import json


# dashboard views logics.


@transaction.atomic
@login_required(login_url='login')
def index(request):
    # filter out post request.
    if request.method == "POST":
        # Student club registration form processing
        if 'StudentClubFormSubmit' in request.POST:
            # get user input values
            club_form = StudentClubForm(request.POST or None)
            # validate the entered values
            if club_form.is_valid():
                # save the entered values if correct
                club_form.save()
                messages.success(request, "Registration successful.")
                return redirect('dashboard')
            else:
                errors = club_form.errors
                return HttpResponse(json.dumps(errors), status=400)
        # Student club representative form processing
        elif 'ClubRepresentativeFormSubmit' in request.POST:
            # get user input values
            club_rep_form = ClubRepresentativeForm(request.POST or None)
            # validate the entered values
            if club_rep_form.is_valid():
                # save the entered values if correct
                club_rep_form.save()
                messages.success(request, "Club Representative registration successful!")
                return redirect('dashboard')
            else:
                errors = club_rep_form.errors
                return HttpResponse(json.dumps(errors), status=400)
        # film form processing
        elif 'FilmFormSubmit' in request.POST:
            # get user input values
            film_form = FilmForm(request.POST or None)
            # validate the entered values
            if film_form.is_valid():
                # save the entered values if correct
                film_form.save()
                messages.success(request, "Film added successfully!")
                return redirect('dashboard')
            else:
                errors = film_form.errors
                return HttpResponse(json.dumps(errors), status=400)
        # Add Screen form processing
        elif 'ScreenFormSubmit' in request.POST:
            # get user input values
            screen_form = ScreenForm(request.POST or None)
            # validate the entered values
            if screen_form.is_valid():
                # save the entered values if correct
                screen_form.save()
                messages.success(request, "Screen added successfully!")
                return redirect('dashboard')
            else:
                errors = screen_form.errors
                return HttpResponse(json.dumps(errors), status=400)
        # Add show form processing
        elif 'ShowFormSubmit' in request.POST:
            # get user input values
            show_form = ShowForm(request.POST or None)
            if show_form.is_valid():
                # save the entered values if correct
                show_form.save()
                messages.success(request, "Show added successfully!")
                return redirect('dashboard')
            else:
                errors = show_form.errors
                return HttpResponse(json.dumps(errors), status=400)
        elif 'DeleteShowFormSubmit' in request.POST:
            try:
                record = Show.objects.get(film__id=int(request.POST['film']))
                record.delete()
                messages.success(request, "Show deleted successfully!")
                return redirect('dashboard')
            except:
                print("Record doesn't exists")
    # Loading all forms for get request
    return render(request, 'studentClub.html', {
        'StudentClubForm': StudentClubForm,
        'ClubRepresentativeForm': ClubRepresentativeForm,
        'FilmForm': FilmForm,
        'ScreenForm': ScreenForm,
        'ShowForm': ShowForm,
    })


@transaction.atomic
@login_required(login_url='login')
def clubRepresentative(request):
    # filter out post request.
    if request.method == "POST":
        # Student club registration form processing
        club_rep_form = ClubRepresentativeForm(request.POST or None)
        # validate the entered values
        if club_rep_form.is_valid():
            # save the entered values if correct
            club_rep_form.save()
            messages.success(request, "Club Representative registration successful!")
            return redirect('clubRepresentative')
        else:
            errors = club_rep_form.errors
            return HttpResponse(json.dumps(errors), status=400)

    return render(request, 'clubRepresentative.html', {
        'ClubRepresentativeForm': ClubRepresentativeForm(),
    })


@transaction.atomic
@login_required(login_url='login')
def addfilm(request):
    # filter out post request.
    if request.method == "POST":
        # Student club registration form processing

        film_form = FilmForm(request.POST or None)
        # validate the entered values
        if film_form.is_valid():
            # save the entered values if correct
            film_form.save()
            messages.success(request, "Film added successfully!")
            return redirect('addfilm')
        else:
            errors = film_form.errors
            return HttpResponse(json.dumps(errors), status=400)

    return render(request, 'addFilm.html', {
        'FilmForm': FilmForm
    })


@transaction.atomic
@login_required(login_url='login')
def addScreen(request):
    # filter out post request.
    if request.method == "POST":
        # Student club registration form processing
        screen_form = ScreenForm(request.POST or None)
        # validate the entered values
        if screen_form.is_valid():
            # save the entered values if correct
            screen_form.save()
            messages.success(request, "Screen added successfully!")
            return redirect('dashboard')
        else:
            errors = screen_form.errors
            return HttpResponse(json.dumps(errors), status=400)
    # Student club representative form processing

    return render(request, 'addScreen.html', {
        'ScreenForm': ScreenForm,
    })


@transaction.atomic
@login_required(login_url='login')
def addShow(request):
    # filter out post request.
    if request.method == "POST":
        show_form = ShowForm(request.POST or None)
        if show_form.is_valid():
            # save the entered values if correct
            show_form.save()
            messages.success(request, "Show added successfully!")
            return redirect('addShow')
        else:
            errors = show_form.errors
            return HttpResponse(json.dumps(errors), status=400)

    return render(request, 'addShow.html', {
        'ShowForm': ShowForm,
    })


@transaction.atomic
@login_required(login_url='login')
def deleteObsoleteFilms(request):
    # filter out post request.
    if request.method == "POST":
        try:
            record = Film.objects.get(id=int(request.POST['id']))
            record.delete()
            messages.success(request, "Film deleted successfully!")
            return redirect('dashboard')
        except:
            print("Record doesn't exists")
    films = Film.objects.exclude(id__in=Show.objects.all().values_list('film__id', flat=True))
    return render(request, 'deleteObsoleteFilms.html', {
        'films': films,
    })


@transaction.atomic
@login_required(login_url='login')
def addAccount(request):
    if request.method == "POST":
        # Student club registration form processing
        if 'AccountFormSubmit' in request.POST:
            # get user input values
            acc_form = AccountForm(request.POST or None)
            # validate the entered values
            if acc_form.is_valid():
                # save the entered values if correct
                acc_form.save()
                messages.success(request, "Account added successfully.")
                return redirect('addAccount')
            else:
                errors = acc_form.errors
                return HttpResponse(json.dumps(errors), status=400)
    accounts = Account.objects.all()
    # Loading all forms for get request
    return render(request, 'AddAccount.html', {
        'AccountForm': AccountForm,
        'accounts': accounts
    })


@transaction.atomic
@login_required(login_url='login')
def editAccount(request, id):
    # dictionary for initial data with
    # field names as keys
    context = {}

    # fetch the object related to passed id
    obj = get_object_or_404(Account, id=id)

    # pass the object as instance in form
    form = AccountForm(request.POST or None, instance=obj)

    # save the data from the form and
    # redirect to detail_view
    if form.is_valid():
        form.save()
        messages.success(request, "Account added successfully.")
        return redirect('registeredAccounts')

    # add form dictionary to context
    context["AccountForm"] = form

    return render(request, "editAccount.html", context)


@transaction.atomic
@login_required(login_url='login')
def registeredAccounts(request):
    if request.method == "POST":
        # Student club registration form processing
        if 'AccountFormSubmit' in request.POST:
            # get user input values
            acc_form = AccountForm(request.POST or None)
            # validate the entered values
            if acc_form.is_valid():
                # save the entered values if correct
                acc_form.save()
                messages.success(request, "Account added successfully.")
                return redirect('registeredAccounts')
            else:
                errors = acc_form.errors
                return HttpResponse(json.dumps(errors), status=400)
    accounts = Account.objects.all()
    # Loading all forms for get request
    return render(request, 'RegisteredAccounts.html', {
        'AccountForm': AccountForm,
        'accounts': accounts
    })


@transaction.atomic
@login_required(login_url='login')
def dailyTransactions(request):
    if request.method == "POST":
        # Student club registration form processing
        if 'AccountFormSubmit' in request.POST:
            # get user input values
            acc_form = AccountForm(request.POST or None)
            # validate the entered values
            if acc_form.is_valid():
                # save the entered values if correct
                acc_form.save()
                messages.success(request, "Account added successfully.")
                return redirect('dailyTransactions')
            else:
                errors = acc_form.errors
                return HttpResponse(json.dumps(errors), status=400)
    accounts = Account.objects.all()
    # Loading all forms for get request
    return render(request, 'DailyTransactions.html', {
        'AccountForm': AccountForm,
        'accounts': accounts
    })


@transaction.atomic
@login_required(login_url='login')
def amendAcount(request):
    if request.method == "POST":
        # Student club registration form processing
        if 'AccountFormSubmit' in request.POST:
            # get user input values
            acc_form = AccountForm(request.POST or None)
            # validate the entered values
            if acc_form.is_valid():
                # save the entered values if correct
                acc_form.save()
                messages.success(request, "Account added successfully.")
                return redirect('amendAcount')
            else:
                errors = acc_form.errors
                return HttpResponse(json.dumps(errors), status=400)
    accounts = Account.objects.all()
    # Loading all forms for get request
    return render(request, 'AmendAccount.html', {
        'AccountForm': AccountForm,
        'accounts': accounts
    })


@transaction.atomic
@login_required(login_url='login')
def accountStatements(request):
    if request.method == "POST":
        # Student club registration form processing
        if 'AccountFormSubmit' in request.POST:
            # get user input values
            acc_form = AccountForm(request.POST or None)
            # validate the entered values
            if acc_form.is_valid():
                # save the entered values if correct
                acc_form.save()
                messages.success(request, "Account added successfully.")
                return redirect('accountStatements')
            else:
                errors = acc_form.errors
                return HttpResponse(json.dumps(errors), status=400)
    accounts = Account.objects.all()
    # Loading all forms for get request
    return render(request, 'ViewStatements.html', {
        'AccountForm': AccountForm,
        'accounts': accounts
    })


@transaction.atomic
@login_required(login_url='login')
def acc_logout(request):
    # Loading all forms for get request
    return render(request, 'logout.html', {
    })


@transaction.atomic
@login_required(login_url='login')
def man_logout(request):
    return render(request, 'man-logout.html')


@transaction.atomic
@login_required(login_url='login')
def deleteScreen(request):
    if request.method == "POST":
        try:
            record = Screen.objects.get(screen_number=int(request.POST['screen_number']))
            record.delete()
            messages.success(request, "Screen deleted successfully!")
            return redirect('dashboard')
        except:
            print("Screen doesn't exists")


def registerPage(request):
    # Check for authorized user
    if request.user.is_authenticated:
        return redirect('home')
    else:
        # Loading createUser form
        form = CreateUserForm()
        if request.method == 'POST':
            # adding post parameters to the form
            form = CreateUserForm(request.POST)
            # check form validation
            if form.is_valid():
                form.save()
                user = form.cleaned_data.get('username')
                messages.success(request, 'Account was created for ' + user)

                return redirect('login')

        context = {'form': form}
        return render(request, 'register.html', context)


# Login page function
def loginPage(request):
    # check for user authentication
    if request.user.is_authenticated:
        # Redirect ro dashboard if authenticated
        return redirect('home')
    else:
        # If the request is post request
        if request.method == 'POST':
            # get user entered details
            username = request.POST.get('username')
            password = request.POST.get('password')
            # authenticate the user
            user = authenticate(request, username=username, password=password)

            if user is not None:
                # create login session
                login(request, user)
                return redirect('dashboard')
            else:
                messages.info(request, 'Username OR password is incorrect')

        context = {}
        return render(request, 'login.html', context)

    # logout user


def logoutUser(request):
    logout(request)
    return redirect('login')
