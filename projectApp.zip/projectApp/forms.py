from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from .models import *
from django import forms


class DateInput(forms.DateInput):
    input_type = 'date'


class CreateUserForm(UserCreationForm):
    class Meta:
        model = User
        fields = ['username', 'email', 'password1', 'password2']

    def __init__(self, *args, **kwargs):
        super(CreateUserForm, self).__init__(*args, **kwargs)
        # self.fields['username'].required = False
        for visible in self.visible_fields():
            visible.field.widget.attrs['class'] = 'form-control'
            # visible.field.label.attrs['class'] = 'short-heading mb-2'
            # visible.field.widget.attrs['placeholder'] = visible.field.label


class StudentClubForm(forms.ModelForm):
    class Meta:
        model = StudentClub
        fields = '__all__'
        widgets = {
            'address': forms.Textarea(attrs={'rows': 2}),
        }


class ClubRepresentativeForm(forms.ModelForm):
    class Meta:
        model = ClubRepresentative
        fields = '__all__'
        widgets = {
            'date_of_birth': DateInput(attrs={'type': 'date'}),
        }


class FilmForm(forms.ModelForm):
    class Meta:
        model = Film
        fields = '__all__'



class ScreenForm(forms.ModelForm):
    class Meta:
        model = Screen
        fields = '__all__'


class ShowForm(forms.ModelForm):
    class Meta:
        model = Show
        fields = '__all__'
        widgets = {
            'time': forms.TimeInput(attrs={'type': 'time'}),
            'date': DateInput(attrs={'type': 'date'}),
        }


class AccountForm(forms.ModelForm):
    class Meta:
        model = Account
        fields = '__all__'
        widgets = {
            'expiry_date': DateInput(attrs={'type': 'date'}),
        }