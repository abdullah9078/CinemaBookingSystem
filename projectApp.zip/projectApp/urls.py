from django.urls import path
# now import the views.py file into this code
from . import views

urlpatterns = [
    path('', views.index, name="dashboard"),
    path('clubRepresentative', views.clubRepresentative, name="clubRepresentative"),
    path('addfilm', views.addfilm, name="addfilm"),
    path('addScreen', views.addScreen, name="addScreen"),
    path('addShow', views.addShow, name="addShow"),
    path('ObsoleteFilm', views.deleteObsoleteFilms, name="deleteObsoleteFilm"),
    path('confirmLogout', views.man_logout, name="confirmLogout"),

    path('manager', views.addAccount, name="addAccount"),
    path('manager/<id>/update', views.editAccount, name="editAccount"),
    path('manager/registeredAccounts', views.registeredAccounts, name="registeredAccounts"),
    path('manager/dailyTransactions', views.dailyTransactions, name="dailyTransactions"),
    path('manager/amendAcount', views.amendAcount, name="amendAcount"),
    path('manager/accountStatements', views.accountStatements, name="accountStatements"),
    path('manager/logout', views.acc_logout, name="account-logout"),

    path('deleteScreen/', views.deleteScreen, name="deleteScreen"),
    path('register/', views.registerPage, name="register"),
    path('login/', views.loginPage, name="login"),
    path('logout/', views.logoutUser, name="logout"),
]
